use bevy::prelude::*;

use app::ApplicationPlugin;
use ui::UIPlugin;

mod app;
mod config;
mod ui;

fn main() {
    App::new()
        .add_plugins(DefaultPlugins.set(ImagePlugin::default_nearest()))
        .insert_resource(ClearColor(Color::rgb(0.5, 0.5, 0.9)))
        .add_plugin(ApplicationPlugin)
        .add_plugin(UIPlugin)
        .run();
}
