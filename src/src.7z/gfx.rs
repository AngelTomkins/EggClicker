use bevy::prelude::*;

pub struct UIPlugin;
